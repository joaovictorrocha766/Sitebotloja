# Painel Flask + Bot Discord
Painel administrativo para seu bot com Flask, pronto para deploy.